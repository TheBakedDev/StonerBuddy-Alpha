__all__ = ["config", "cli", "bot", "api", "ui"]
__version__ = "0.1.0"

# Convenience: allow `from stoner_buddy import bot`
try:
    from .bot.stoner_buddy import bot as bot  # type: ignore
except Exception:
    pass
