import asyncio, os, logging
import uvicorn
from .config import load_settings
from .api.app import app  # ensures routes are registered
from .bot.stoner_buddy import bot

async def _run_uvicorn(host: str, port: int):
    config = uvicorn.Config(app, host=host, port=port, log_level="info")
    server = uvicorn.Server(config)
    await server.serve()

async def main_async():
    s = load_settings()
    host = os.getenv("API_HOST", "127.0.0.1")
    port = int(os.getenv("PORT", "8000"))

    # Start API and bot concurrently
    await asyncio.gather(
        _run_uvicorn(host, port),
        bot.start(s.discord_token),
    )

def main():
    # Run both on one event loop
    try:
        asyncio.run(main_async())
    except KeyboardInterrupt:
        pass
    finally:
        if bot and bot.is_closed() is False:
            asyncio.run(bot.close())

if __name__ == "__main__":
    main()
