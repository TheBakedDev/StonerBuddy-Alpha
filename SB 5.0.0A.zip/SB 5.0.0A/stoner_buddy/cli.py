import argparse
import logging
import importlib
import runpy
import os
from .config import load_settings

def setup_logging(level: str):
    logging.basicConfig(level=getattr(logging, level.upper(), logging.INFO),
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")

def _try_call(module, candidates=("main","run","start","start_bot")):
    for name in candidates:
        fn = getattr(module, name, None)
        if callable(fn):
            return fn()
    return None

def run_bot():
    s = load_settings()
    setup_logging(s.log_level)
    try:
        mod = importlib.import_module("stoner_buddy.bot.legacy_run")
        called = _try_call(mod)
        if called is None:
            # fall back: execute module as a script
            runpy.run_module("stoner_buddy.bot.legacy_run", run_name="__main__")
    except Exception as e:
        logging.exception("Bot failed: %s", e)

def run_api():
    s = load_settings()
    setup_logging(s.log_level)
    try:
        mod = importlib.import_module("stoner_buddy.api.app")
        # If FastAPI app exists, try to serve with uvicorn
        app = getattr(mod, "app", None)
        if app is not None:
            import uvicorn
            uvicorn.run(app, host="0.0.0.0", port=int(os.getenv("PORT", "8000")))
        else:
            # Otherwise run module (may start its own server)
            runpy.run_module("stoner_buddy.api.app", run_name="__main__")
    except Exception as e:
        logging.exception("API failed: %s", e)

def run_ui():
    s = load_settings()
    setup_logging(s.log_level)
    try:
        mod = importlib.import_module("stoner_buddy.ui.gui")
        called = _try_call(mod, candidates=("main","run","start","launch"))
        if called is None:
            runpy.run_module("stoner_buddy.ui.gui", run_name="__main__")
    except Exception as e:
        logging.exception("UI failed: %s", e)

def main():
    parser = argparse.ArgumentParser(prog="stoner-buddy", description="Stoner Buddy controller")
    sub = parser.add_subparsers(dest="cmd", required=True)
    sub.add_parser("bot", help="run the Discord bot")
    sub.add_parser("api", help="run the API server")
    sub.add_parser("ui", help="run the desktop UI")
    sub.add_parser("panel", help="run API and Discord bot together")
    args = parser.parse_args()
    if args.cmd == "bot":
        run_bot()
    elif args.cmd == "api":
        run_api()
    elif args.cmd == "ui":
        run_ui()
    elif args.cmd == "panel":
        from .panel_server import main as run_panel
        run_panel()

if __name__ == "__main__":
    main()
