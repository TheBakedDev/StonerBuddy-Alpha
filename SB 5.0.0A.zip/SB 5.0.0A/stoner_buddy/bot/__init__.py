# Expose bot and TOKEN (if defined) from original module
from .stoner_buddy import bot  # discord.Client
try:
    from .stoner_buddy import TOKEN
except Exception:
    TOKEN = None
