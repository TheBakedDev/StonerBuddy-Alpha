"""Thin compatibility shim for the original bot.

- Imports `bot` and `TOKEN` from the original module.
- Runs the bot with that token.
Use via: `python -m stoner_buddy.cli bot`
"""
from .stoner_buddy import bot  # original discord.Client
try:
    from .stoner_buddy import TOKEN  # expects TOKEN=os.getenv("DISCORD_TOKEN")
except Exception as e:
    TOKEN = None

def main():
    # Don't reassign TOKEN; that would make it a local and cause UnboundLocalError
    import os
    token = TOKEN or os.getenv("DISCORD_TOKEN")
    if not token:
        raise RuntimeError("DISCORD_TOKEN is not set. Create a .env from .env.example.")
    bot.run(token)

if __name__ == "__main__":
    main()
