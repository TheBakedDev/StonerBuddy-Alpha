from __future__ import annotations
import os, asyncio
from typing import Optional
from fastapi import FastAPI, Header, HTTPException, Body
from pydantic import BaseModel

# Import the SAME bot instance
try:
    from stoner_buddy.bot.stoner_buddy import bot  # discord.Client
except Exception as e:
    bot = None

app = FastAPI(title="Stoner Buddy API")

# Auth
API_KEY = os.getenv("PANEL_API_KEY")

def check_auth(auth: Optional[str]):
    if API_KEY and auth != f"Bearer {API_KEY}":
        raise HTTPException(status_code=401, detail="Unauthorized")

@app.get("/health")
def health():
    return {"ok": True, "bot_ready": bool(getattr(bot, "is_ready", lambda: False)())}

@app.get("/info")
def info():
    return {
        "name": "Stoner Buddy",
        "status": "Online and vibing.",
        "version": "v1.0.0",
        "auth": "ON" if API_KEY else "OFF",
    }

@app.get("/commands")
def commands():
    return {
        "ok": True,
        "commands": [
            "help",
            "say <channel_id> <text>",
            "dm <user_id> <text>",
            "purge <channel_id> <count>"
        ]
    }

class ConsoleBody(BaseModel):
    text: str

@app.post("/console")
async def console(body: ConsoleBody = Body(...), authorization: Optional[str] = Header(default=None)):
    check_auth(authorization)
    if bot is None:
        raise HTTPException(status_code=500, detail="Bot module not loaded")
    if not bot.is_ready():
        raise HTTPException(status_code=503, detail="Bot not ready")

    t = (body.text or "").strip()
    if not t:
        raise HTTPException(status_code=400, detail="Empty command")

    parts = t.split(" ", 2)
    cmd = parts[0].lower()

    # SAY
    if cmd == "say" and len(parts) >= 3:
        channel_id = int(parts[1])
        content = parts[2]
        ch = bot.get_channel(channel_id)
        if ch is None: raise HTTPException(status_code=404, detail="Channel not found")
        await ch.send(content)
        return {"ok": True, "result": "message sent"}

    # DM
    if cmd == "dm" and len(parts) >= 3:
        user_id = int(parts[1])
        content = parts[2]
        user = await bot.fetch_user(user_id)
        await user.send(content)
        return {"ok": True, "result": "dm sent"}

    # PURGE
    if cmd == "purge" and len(parts) >= 3:
        channel_id = int(parts[1])
        count = int(parts[2])
        ch = bot.get_channel(channel_id)
        if ch is None: raise HTTPException(status_code=404, detail="Channel not found")
        deleted = await ch.purge(limit=count)
        return {"ok": True, "result": f"deleted {len(deleted)} messages"}

    if cmd == "help":
        return await commands()

    raise HTTPException(status_code=400, detail="Unknown/invalid command")
