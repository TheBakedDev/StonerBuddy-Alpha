from dataclasses import dataclass
import os

try:
    from dotenv import load_dotenv, find_dotenv  # Optional
    load_dotenv(find_dotenv(), override=False)
except Exception:
    pass

@dataclass
class Settings:
    discord_token: str
    command_prefix: str = "!"
    log_level: str = "INFO"
    maintenance_message: str | None = None
    panel_api_key: str | None = None

def load_settings() -> Settings:
    token = os.getenv("DISCORD_TOKEN", "")
    if not token:
        raise RuntimeError("DISCORD_TOKEN is not set. Create a .env from .env.example.")
    prefix = os.getenv("COMMAND_PREFIX", "!")
    log_level = os.getenv("LOG_LEVEL", "INFO")
    maintenance_message = os.getenv("MAINTENANCE_MESSAGE")
    panel_api_key = os.getenv("PANEL_API_KEY")
    return Settings(token, prefix, log_level, maintenance_message, panel_api_key)
