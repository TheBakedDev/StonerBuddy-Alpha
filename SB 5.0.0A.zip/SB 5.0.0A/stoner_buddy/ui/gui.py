from __future__ import annotations
import sys, os, json, requests
from PySide6.QtCore import Qt
from PySide6.QtGui import QAction, QTextCursor, QPixmap
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QTextEdit, QLabel, QLineEdit, QDialog, QComboBox,
    QDialogButtonBox, QFileDialog, QMessageBox
)

def load_cfg():
    p = os.path.join(os.path.expanduser("~"), ".stoner_buddy_exe.json")
    if os.path.exists(p):
        try: return json.loads(open(p, "r", encoding="utf-8").read())
        except Exception: pass
    return {"api_base": None, "api_key": None, "theme": "baked"}

def save_cfg(cfg):
    p = os.path.join(os.path.expanduser("~"), ".stoner_buddy_exe.json")
    open(p, "w", encoding="utf-8").write(json.dumps(cfg, indent=2))

class QtLogger:
    def __init__(self, text_edit: QTextEdit):
        self.text_edit = text_edit

    def _append(self, prefix: str, msg: str) -> None:
        self.text_edit.append(f"{prefix}{msg}")
        self.text_edit.moveCursor(QTextCursor.End)
        self.text_edit.ensureCursorVisible()

    def info(self, msg: str) -> None:
        self._append("", msg)

    def warn(self, msg: str) -> None:
        self._append("⚠ ", msg)

    def error(self, msg: str) -> None:
        self._append("✖ ", msg)


class SettingsDialog(QDialog):
    def __init__(self, cfg, parent=None):
        super().__init__(parent); self.setWindowTitle("Settings"); self.cfg = cfg
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("API Base (e.g. http://localhost:8000)")); self.api_base = QLineEdit(self); self.api_base.setText(cfg.get("api_base") or ""); layout.addWidget(self.api_base)
        layout.addWidget(QLabel("API Key (Authorization: Bearer ...)")); self.api_key = QLineEdit(self); self.api_key.setText(cfg.get("api_key") or ""); layout.addWidget(self.api_key)
        layout.addWidget(QLabel("Theme")); self.theme = QComboBox(self); self.theme.addItems(["baked","classic"]); self.theme.setCurrentText(cfg.get("theme") or "baked"); layout.addWidget(self.theme)
        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel, parent=self); buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject); layout.addWidget(buttons)
    def get_config(self): return {"api_base": self.api_base.text().strip() or None, "api_key": self.api_key.text().strip() or None, "theme": self.theme.currentText() or "baked"}

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle("Stoner Buddy — EXT"); self.resize(980, 640)
        self.cfg = load_cfg()
        central = QWidget(self); self.setCentralWidget(central); v = QVBoxLayout(central)
        banner_row = QHBoxLayout(); self.banner = QLabel(self); self.banner.setAlignment(Qt.AlignLeft|Qt.AlignVCenter); self.banner.setFixedHeight(160)
        self.banner.setStyleSheet("background-color:#111;color:#aaa;padding:8px;border-radius:12px;"); banner_row.addWidget(self.banner,1)
        self.btn_set_banner = QPushButton("Set Banner Image"); self.btn_set_banner.clicked.connect(self.pick_banner); banner_row.addWidget(self.btn_set_banner,0); v.addLayout(banner_row)
        self.load_banner(os.path.join(os.path.dirname(__file__), "assets", "banner.png"))
        row = QHBoxLayout()
        self.btn_ping = QPushButton("Ping API"); self.btn_cmds = QPushButton("List Console Verbs"); self.btn_console = QPushButton("Send Console")
        row.addWidget(self.btn_ping); row.addWidget(self.btn_cmds); row.addWidget(self.btn_console); v.addLayout(row)
        self.log = QTextEdit(self); self.log.setReadOnly(True); v.addWidget(self.log,1)
        cmd_row = QHBoxLayout(); self.cmd_in = QLineEdit(self); self.cmd_in.setPlaceholderText("say 123... hello | dm 111... sup | purge 123... 10 | announce 123... text | embed 123... Title|Description | timeout <guild> <user> <s> | ban/unban/kick <guild> <user> [reason]"); self.btn_send = QPushButton("Send")
        cmd_row.addWidget(self.cmd_in,1); cmd_row.addWidget(self.btn_send,0); v.addLayout(cmd_row)
        self.status = self.statusBar(); self.logger = QtLogger(self.log)
        settings_action = QAction("Settings", self); settings_action.triggered.connect(self.open_settings); self.menuBar().addAction(settings_action)
        self.btn_ping.clicked.connect(self.do_ping); self.btn_cmds.clicked.connect(self.do_cmds); self.btn_console.clicked.connect(self.on_send); self.btn_send.clicked.connect(self.on_send); self.cmd_in.returnPressed.connect(self.on_send)
        self.logger.info("Ready. Configure API in Settings, then try a console command.")

    def headers(self):
        h = {"Content-Type":"application/json"}; key = self.cfg.get("api_key"); 
        if key: h["Authorization"] = f"Bearer {key}"; 
        return h

    def load_banner(self, path: str) -> None:
        if path and os.path.exists(path):
            pm = QPixmap(path); 
            if not pm.isNull(): self.banner.setPixmap(pm.scaledToHeight(160, Qt.SmoothTransformation)); return
        self.banner.setText("Drop banner at assets/banner.png or click 'Set Banner Image'")

    def pick_banner(self):
        path, _ = QFileDialog.getOpenFileName(self, "Pick banner image", "", "Images (*.png *.jpg *.jpeg *.bmp)")
        if path:
            assets_dir = os.path.join(os.path.dirname(__file__), "assets"); os.makedirs(assets_dir, exist_ok=True)
            target = os.path.join(assets_dir, "banner.png")
            try:
                with open(path, "rb") as src, open(target, "wb") as dst: dst.write(src.read())
                self.load_banner(target); self.logger.info("Banner updated.")
            except Exception as e: QMessageBox.critical(self, "Error", str(e))

    def do_ping(self):
        try:
            r = requests.get((self.cfg.get("api_base") or "") + "/health", timeout=5)
            self.logger.info(str(r.json()))
        except Exception as e: self.logger.error(str(e))

    def do_cmds(self):
        try:
            r = requests.get((self.cfg.get("api_base") or "") + "/commands", timeout=5)
            self.logger.info("Console verbs: " + ", ".join(r.json().get("console", [])))
        except Exception as e: self.logger.error(str(e))

    def on_send(self):
        txt = self.cmd_in.text().strip()
        if not txt: return
        try:
            r = requests.post((self.cfg.get("api_base") or "") + "/console", headers=self.headers(), json={"text": txt}, timeout=10)
            self.logger.info(str(r.json()))
        except Exception as e: self.logger.error(str(e))
        self.cmd_in.clear()

    def open_settings(self):
        dlg = SettingsDialog(self.cfg, self)
        if dlg.exec() == QDialog.Accepted:
            self.cfg = dlg.get_config(); save_cfg(self.cfg); self.logger.info("Settings saved.")

def main():
    app = QApplication(sys.argv); win = MainWindow(); win.show(); sys.exit(app.exec())

if __name__ == "__main__":
    main()
